from django.shortcuts import render
from .models import Contact
# Create your views here.


def index(request):
	return render(request, "index.html")
	
def about(request):
	return render(request, "about.html")
	
def contact(request):
	return render(request, "contactus.html")
	
def services(request):
	return render(request, "services.html")
	
def showcase(request):
	return render(request, "showcase.html")
	
def actionpage(request):
	if request.method == "POST":
		fname = request.POST["firstname"]
		lname = request.POST["lastname"]
		email = request.POST["emailid"]
		phone = request.POST["phoneno"]
		subject = request.POST["subject"]
		country = request.POST["country"]
		Contact(fname = fname, lname = lname , email = email,phone = phone, subject = subject, country = country).save()
	return render(request, "actionpage.html")
	
